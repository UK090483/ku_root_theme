wp.blocks.registerBlockStyle( 'core/heading', [ 
    {
        name: 'default',
        label: 'Default',
        isDefault: true,
    },
    {
        name: 'jmh-text-color',
        label: 'Jeder mussen Handeln'
    }
]); 


wp.blocks.registerBlockStyle( 'core/paragraph', [ 
    {
        name: 'default',
        label: 'Default',
        isDefault: true,
    },
    {
        name: 'jmh-text-color',
        label: 'Jeder mussen Handeln'
    }
]); 

wp.blocks.registerBlockStyle( 'core/button', [ 
 
    {
        name: 'jmh-button-color',
        label: 'Jeder mussen Handeln'
    }
]); 

wp.blocks.registerBlockStyle( 'core/gallery', [ 
    {
        name: 'default',
        label: 'Default',
        isDefault: true,
    },

    {
        name: 'jmh-gallery',
        label: 'Jeder mussen Handeln unterstützer'
    }
]); 




